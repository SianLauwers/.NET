﻿using System;

namespace Shop.DAL
{
    public class Class1
    {
    }
}
